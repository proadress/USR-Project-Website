// components/Main.tsx

export default function Main({ children }) {
    return <main className="">{children}</main>;
}